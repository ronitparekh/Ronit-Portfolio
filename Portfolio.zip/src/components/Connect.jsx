import profilePic from "../assets/ProfilePic.jpeg";

export default function Connect() {
  return (
    <section id="contact" className="px-6 py-32">
      <div className="mx-auto max-w-6xl">
        
        {/* CTA CARD */}
        <div className="mb-24 grid grid-cols-1 items-center gap-12 rounded-2xl border border-border bg-card p-8 md:grid-cols-2 md:p-12">
          
          {/* Left */}
          <div>
            <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-border bg-bg px-4 py-2 text-sm font-light text-textSecondary">
              ● Let’s Connect
            </div>

            <h2 className="mb-4 text-4xl font-light text-white md:text-5xl">
              Let’s Build Something Together
            </h2>

            <p className="mb-10 max-w-xl text-base font-light leading-relaxed text-textSecondary">
              Have a project in mind or just want to connect?  
              I’m always open to discussing new ideas, collaborations,
              or opportunities.
            </p>

            <div className="flex gap-4">
              <a
                href="mailto:your-email@example.com"
                className="inline-flex items-center justify-center rounded-full bg-white px-7 py-3 text-sm font-medium text-black transition hover:opacity-90"
              >
                Get Started
              </a>

              <a
                href="#projects"
                className="inline-flex items-center justify-center rounded-full border border-border bg-bg px-7 py-3 text-sm font-light text-white transition hover:bg-white hover:text-black"
              >
                See All Projects
              </a>
            </div>
          </div>

          {/* Right (image placeholder like Framer) */}
          <div className="overflow-hidden rounded-xl">
            <img
              src={profilePic}
              alt="Profile Picture"
              className="aspect-4/3 h-full w-full object-cover md:aspect-square"
            />
          </div>
        </div>

        {/* FOOTER */}
        <footer className="flex flex-col items-center justify-between gap-6 border-t border-border pt-8 text-sm text-textSecondary md:flex-row">
          
          <span>© {new Date().getFullYear()} Ronit Parekh</span>

          <div className="flex gap-6">
            <a href="#home" className="hover:text-white transition">Home</a>
            <a href="#projects" className="hover:text-white transition">Projects</a>
            <a href="#resume" className="hover:text-white transition">Resume</a>
            <a href="#contact" className="hover:text-white transition">Contact</a>
          </div>

          <div className="flex gap-4">
            <a href="#" className="hover:text-white transition">GitHub</a>
            <a href="#" className="hover:text-white transition">LinkedIn</a>
            <a href="#" className="hover:text-white transition">Email</a>
          </div>

        </footer>
      </div>
    </section>
  );
}
