import profilePic from "../assets/ProfilePic.jpeg";

export default function ProfileExperience() {
  const skillChips = [
    "UI/UX Design",
    "Full-Stack Dev",
    "Branding",
    "Illustration",
  ];

  const experiences = [
    {
      role: "Volunteer",
      company: "Ariaro 2.0 (Tech Event), Karnavati University",
      year: "2024",
    },
    {
      role: "Organising Team Member",
      company: "Ariaro 3.0 (Tech Event)",
      year: "2025",
    },
    {
      role: "Frontend Developer",
      company: "Optimatrix Solutions",
      year: "2025",
    },
    {
      role: "Software Engineer",
      company: "Seven Square Technosoft",
      year: "2025 – Present",
    },
  ];

  return (
    <section className="px-6 py-28">
      <div className="mx-auto max-w-6xl">
        {/* Heading */}
        <div className="mb-12 text-center">
          <div className="mb-5 inline-flex items-center gap-3 rounded-full bg-[#121212] px-4 py-2 text-sm font-medium text-white shadow-[0_0_0_2px_rgba(255,255,255,0.07),0_12px_30px_rgba(0,0,0,0.55)]">
            <span
              className="inline-flex h-4 w-4 items-center justify-center"
              aria-hidden="true"
            >
              <span className="relative h-3 w-3 rounded-full border border-white/70">
                <span className="absolute inset-0 m-auto h-1 w-1 rounded-full bg-white/90" />
              </span>
            </span>
            Full-Stack Developer
          </div>

          <h2 className="mb-3 font-satoshi text-[40px] font-normal leading-[1.05] tracking-tight md:text-[56px]">
            Ronit Parekh, <span className="text-white/60">Your Developer</span>
          </h2>

          <p className="mx-auto max-w-2xl font-jakarta text-sm font-normal leading-relaxed text-white/60 md:text-base">
            Brief initial presentation of myself and my previous experiences.
          </p>
        </div>

        {/* Cards */}
        <div className="grid grid-cols-1 gap-8 md:grid-cols-[0.9fr_1.1fr]">
          {/* PROFILE CARD */}
          <div className="relative rounded-3xl border border-white/10 bg-black/35 p-7 backdrop-blur-2xl shadow-[0_18px_55px_rgba(0,0,0,0.65)] md:p-8">
            <div className="relative mb-6 overflow-hidden rounded-2xl border border-white/10 bg-black">
              <img
                src={profilePic}
                alt="Ronit Parekh"
                className="h-64 w-full object-cover"
                loading="lazy"
              />

              <div className="absolute bottom-3 left-3 inline-flex items-center gap-2 rounded-full border border-white/10 bg-black/55 px-3 py-1.5 text-xs font-medium text-white/80 backdrop-blur">
                <span className="h-2 w-2 rounded-full bg-emerald-400" />
                Available for work
              </div>
            </div>

            <h3 className="mb-1 font-satoshi text-xl font-normal text-white">
              Hello I am Ronit Parekh
            </h3>
            <p className="mb-5 font-jakarta text-sm font-normal text-white/55">
              Full-Stack Developer Based in Ahmedabad
            </p>

            <div className="mb-6 flex items-center gap-3">
              <a
                href="#"
                className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-white/10 bg-black/30 text-xs font-medium text-white/70 transition hover:text-white"
                aria-label="GitHub"
              >
                GH
              </a>
              <a
                href="#"
                className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-white/10 bg-black/30 text-xs font-medium text-white/70 transition hover:text-white"
                aria-label="LinkedIn"
              >
                IN
              </a>
              <a
                href="#"
                className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-white/10 bg-black/30 text-xs font-medium text-white/70 transition hover:text-white"
                aria-label="Email"
              >
                @
              </a>
            </div>

            <div className="h-px w-full bg-white/10" />

            <a
              href="#contact"
              className="mt-6 inline-flex items-center justify-center rounded-full border border-white/10 bg-black/30 px-6 py-3 text-sm font-medium text-white transition hover:bg-white hover:text-black"
            >
              Connect with me
            </a>
          </div>

          {/* EXPERIENCE CARD */}
          <div className="rounded-3xl border border-white/10 bg-black/35 p-7 backdrop-blur-2xl shadow-[0_18px_55px_rgba(0,0,0,0.65)] md:p-8">
            <p className="mb-6 font-jakarta text-sm font-normal leading-relaxed text-white/65">
              I’m Ronit Parekh, a Full-Stack Developer with a passion for building modern web apps—
              translating ideas into clean UIs, robust APIs, and intuitive digital experiences.
            </p>

            <div className="mb-7 flex flex-wrap gap-2">
              {skillChips.map((chip) => (
                <span
                  key={chip}
                  className="rounded-full border border-white/10 bg-black/25 px-3 py-1.5 text-xs font-medium text-white/70"
                >
                  {chip}
                </span>
              ))}
            </div>

            <div className="space-y-6">
              {experiences.map((exp) => (
                <div
                  key={`${exp.role}-${exp.company}-${exp.year}`}
                  className="grid grid-cols-1 gap-2 border-t border-white/10 pt-5 md:grid-cols-[170px_1fr_120px] md:gap-4"
                >
                  <div className="text-sm font-medium text-white/80">{exp.role}</div>
                  <div className="text-sm font-normal text-white/55">{exp.company}</div>
                  <div className="text-sm font-normal text-white/55 md:text-right">
                    {exp.year}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
