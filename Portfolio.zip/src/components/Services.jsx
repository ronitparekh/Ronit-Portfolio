const services = [
  {
    title: "Full-Stack Web Development",
    description:
      "End-to-end web application development using React, Node.js, and modern backend architectures.",
  },
  {
    title: "Frontend Engineering",
    description:
      "Responsive, accessible, and performant user interfaces built with React and Tailwind CSS.",
  },
  {
    title: "Backend & API Development",
    description:
      "Secure, scalable REST APIs with authentication, authorization, and database integration.",
  },
  {
    title: "System Design & Architecture",
    description:
      "Designing clean, scalable architectures suitable for real-world production environments.",
  },
];

const skills = [
  "React",
  "Node.js",
  "Express",
  "MongoDB",
  "PostgreSQL",
  "JWT Auth",
  "REST APIs",
  "Tailwind CSS",
  "Git",
  "System Design",
];

export default function Services() {
  return (
    <section className="px-6 py-32">
      <div className="mx-auto max-w-6xl">
        
        {/* Pill */}
        <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-border bg-card px-4 py-2 text-sm font-light text-textSecondary">
          ● Services
        </div>

        {/* Heading */}
        <h2 className="mb-4 text-4xl font-light text-white md:text-5xl">
          What I Can Help You With
        </h2>

        {/* Subtext */}
        <p className="mb-16 max-w-2xl text-base font-light text-textSecondary">
          I offer development services focused on building reliable,
          scalable, and maintainable web applications.
        </p>

        {/* Services grid */}
        <div className="mb-16 grid grid-cols-1 gap-8 md:grid-cols-2">
          {services.map((service, index) => (
            <div
              key={index}
              className="rounded-2xl border border-border bg-card p-6"
            >
              <h3 className="mb-3 text-lg font-light text-white">
                {service.title}
              </h3>
              <p className="text-sm font-light leading-relaxed text-textSecondary">
                {service.description}
              </p>
            </div>
          ))}
        </div>

        {/* Skill chips */}
        <div className="flex flex-wrap gap-3">
          {skills.map((skill, index) => (
            <span
              key={index}
              className="rounded-full border border-border bg-card px-4 py-2 text-sm font-light text-textSecondary"
            >
              {skill}
            </span>
          ))}
        </div>

      </div>
    </section>
  );
}
