const steps = [
  {
    step: "01",
    title: "Understand",
    description:
      "I begin by deeply understanding the problem, business goals, and user requirements to set a strong foundation.",
  },
  {
    step: "02",
    title: "Design",
    description:
      "I plan system architecture and UI structure, ensuring scalability, usability, and maintainability.",
  },
  {
    step: "03",
    title: "Develop",
    description:
      "I build clean, modular, and efficient code using modern frontend and backend technologies.",
  },
  {
    step: "04",
    title: "Deliver",
    description:
      "I test thoroughly, optimize performance, and deliver a reliable solution ready for real-world use.",
  },
];

export default function Process() {
  return (
    <section className="px-6 py-32">
      <div className="mx-auto max-w-6xl">
        
        {/* Pill */}
        <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-border bg-card px-4 py-2 text-sm font-light text-textSecondary">
          ● How it works
        </div>

        {/* Heading */}
        <h2 className="mb-4 text-4xl font-light text-white md:text-5xl">
          Process Is Everything
        </h2>

        {/* Subtext */}
        <p className="mb-16 max-w-2xl text-base font-light text-textSecondary">
          A simple, structured approach helps me build scalable and reliable
          full-stack applications efficiently.
        </p>

        {/* Steps */}
        <div className="grid grid-cols-1 gap-8 md:grid-cols-4">
          {steps.map((item) => (
            <div
              key={item.step}
              className="rounded-2xl border border-border bg-card p-6"
            >
              <span className="mb-4 block text-sm font-light text-textSecondary">
                {item.step}
              </span>

              <h3 className="mb-3 text-lg font-light text-white">
                {item.title}
              </h3>

              <p className="text-sm font-light leading-relaxed text-textSecondary">
                {item.description}
              </p>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
}
