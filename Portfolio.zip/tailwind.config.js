/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,jsx}",
  ],
  theme: {
    extend: {
      fontFamily: {
        sans: ["Inter", "system-ui", "sans-serif"],
        satoshi: ["Satoshi", "Inter", "system-ui", "sans-serif"],
        jakarta: ["Plus Jakarta Sans", "Inter", "system-ui", "sans-serif"],
        poppins: ["Poppins", "Inter", "system-ui", "sans-serif"],
      },
      colors: {
        bg: "#0b0b0b",
        card: "#111111",
        border: "#1f1f1f",
        textPrimary: "#ffffff",
        textSecondary: "#b5b5b5",
      },
      borderRadius: {
        pill: "9999px",
      },
    },
  },
  plugins: [],
}
